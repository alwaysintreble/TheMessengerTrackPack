﻿CURRENT_ROOM = nil
CURRENT_ROOM_ADDRESS = "Level_13_TowerOfTimeHQ"

ROOM_MAPPING =
{
    ["Level_01_NinjaVillage"] = {"Ninja Village"},
    ["Level_02_AutumnHills"] = {"Autumn Hills"},
    ["Level_03_ForlornTemple"] = {"Forlorn Temple"},
    ["Level_04_Catacombs"] = {"Catacombs"},
    ["Level_04_B_DarkCave"] = {"Overworld"},
    ["Level_04_C_RiviereTurquoise"] = {"Riviere Turquoise"},
    ["Level_05_A_HowlingGrotto"] = {"Howling Grotto"},
    ["Level_05_B_SunkenShrine"] = {"Sunken Shrine"},
    ["Level_06_A_BambooCreek"] = {"Bamboo Creek"},
    ["Level_07_QuillshroomMarsh"] = {"Quillshroom Marsh"},
    ["Level_08_SearingCrags"] = {"Searing Crags"},
    ["Level_09_A_GlacialPeak"] = {"Glacial Peak"},
    ["Level_09_B_ElementalSkylands"] = {"Elemental Skylands"},
    ["Level_10_A_TowerOfTime"] = {"Tower of Time"},
    ["Level_11_A_CloudRuins"] = {"Cloud Ruins"},
    ["Level_11_B_MusicBox"] = {"Overworld"},
    ["Level_12_UnderWorld"] = {"Underworld"},
    ["Level_13_TowerOfTimeHQ"] = {"Overworld"},
    ["Level_14_CorruptedFuture"] = {"Overworld"}
}